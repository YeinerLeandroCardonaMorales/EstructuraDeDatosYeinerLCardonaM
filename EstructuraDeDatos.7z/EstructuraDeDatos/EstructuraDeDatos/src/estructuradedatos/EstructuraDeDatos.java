/*
*Esta clase es la clase principal generada automaticamente al iniciar un 
 proyecto desde netbeans
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estructuradedatos;

import estructurasdedatos.estructuraobjeto.Persona;

/**
 *
 * @author utp
 */
public class EstructuraDeDatos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Persona juan = new Persona();
        juan.setNombre("Juan Perez");
        juan.getDireccion();
       
        System.out.println("Nombre: " + juan.getNombre()
                +" Direccion: "+ juan.getDireccion());
        
        
        
        
    }
    
}
