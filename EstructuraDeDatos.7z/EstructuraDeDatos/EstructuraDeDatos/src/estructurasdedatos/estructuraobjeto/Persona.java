/*
 * Fecha: 22/02/2017
 * Descripcion: Clase persona, primera estructura de datos, una clase es una 
               plantilla de donde puedo instanciar objetos de tipo personas
               una instancia es una variable o un lugar en la memoria del 
               computador y almacena los atributos y metodos que tiene el objeto
 * Autor: Yeiner Leandro Cardona Morales
 */

//definiendo el paquete donde esta la clase
package estructurasdedatos.estructuraobjeto;

/**
 *
 * @author utp
 */

//la firma de la clase
public class Persona {
    private String nombre;
    private int cedula;
    private String direccion = "Calle 19 #15-12";
    private String telefono;

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        //codifico las reglas de negocio para cambiar un atributo
        this.nombre = nombre;
    }

    /**
     * @return the cedula
     */
    public int getCedula() {
        return cedula;
    }

    /**
     * @return the direccion
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * @param direccion the direccion to set
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * @return the telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * @param telefono the telefono to set
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * @param cedula the cedula to set
     */
    public void setCedula(int cedula) {
        this.cedula = cedula;
    }
    
    
    
    
    
}
